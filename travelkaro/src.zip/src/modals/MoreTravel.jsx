import {
    Menu,
    MenuButton,
    MenuList,
    MenuItem,
    MenuItemOption,
    MenuGroup,
    MenuOptionGroup,
    MenuDivider,
  } from '@chakra-ui/react'
  import {Image,Button} from "@chakra-ui/react"
  import { useDisclosure } from '@chakra-ui/react'
  import { useState } from "react"


  function MoreTravel(){
    // const { isOpen, onOpen, onClose } = useDisclosure()
    //  const [size,setSize] = useState("xs")

    //  const handleOpen = (size) => {
    //       onOpen()
    //  }

      return <>    
 <Menu>
  <MenuButton>
  <p color='white' border="1px solid white">More Travel &#709;</p> 
  </MenuButton>
  <MenuList>
    <MenuItem minH='48px'>
      <Image
        boxSize='2rem'
        borderRadius='full'
        src='https://placekitten.com/100/100'
        alt='Fluffybuns the destroyer'
        mr='12px'
      />
      <span>Stays</span>
    </MenuItem>
    <MenuItem minH='40px'>
      <Image
        boxSize='2rem'
        borderRadius='full'
        src='https://placekitten.com/120/120'
        alt='Simon the pensive'
        mr='12px'
      />
      <span>Flights</span>
    </MenuItem>
  </MenuList>
</Menu>
      </>
  }

  export default MoreTravel